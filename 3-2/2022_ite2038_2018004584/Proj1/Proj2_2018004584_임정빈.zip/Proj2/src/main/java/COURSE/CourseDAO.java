package COURSE;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

public class CourseDAO {
    private Connection conn;
    private PreparedStatement pstat;
    private ResultSet rs;
    private PreparedStatement pstat1;
    private ResultSet rs1;

    public CourseDAO(){
        try{
            String dbURL = "jdbc:mysql://localhost:3307/DB2018004584?serverTimezone=Asia/Seoul";
            String dbID = "root";
            String dbPW = "";

            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(dbURL, dbID, dbPW);
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public int course_person(Integer class_id){
        String SQL = "SELECT COUNT(ID) AS course_person FROM takes WHERE class_id=?";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setInt(1, class_id);
            rs=pstat.executeQuery();

            if(rs.next()) {
                return rs.getInt("course_person");
            }
        } catch (Exception e){
            e.printStackTrace();
        }
        return 0;
    }

    public String time_id(Integer class_id){
        String SQL = "SELECT start_time_id, end_time_id FROM class_time WHERE class_id=?";
        String result="";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setInt(1, class_id);
            rs=pstat.executeQuery();

            while(rs.next()) {
                result += change_date(rs.getInt("start_time_id"), rs.getInt("end_time_id"));
            }
            return result;
        } catch (Exception e){
            e.printStackTrace();
        }
        return "비지정";
    }
    public String change_date(Integer start_time, Integer end_time){
        String result ="";
        int time_id1 = start_time; //시작시간
        int time_id2 = end_time; // 종료시간
        int a, b, c; // 시작시간
        int d, e, f; // 종료시간
        a = time_id1/10000;
        b= (time_id1%10000)/100;
        c = time_id1%100;
        d = time_id2/10000;
        e = (time_id2%10000)/100;
        f = time_id2%100;
        if (a==0 && d == 0)
            return "비지정";
        if(a==1)
            result +="월";
        else if(a==2)
            result += "화";
        else if(a==3)
            result +="수";
        else if(a==4)
            result += "목";
        else if(a==5)
            result +="금";
        else if(a==6)
            result += "토";
        else
            result += "일";
        result += Integer.toString(b);
        result +="시";
        if(c != 0){
            result += Integer.toString(c);
            result +="분";
        }
        result +="~";
        if(a != d){
            if(d==1)
                result += "월";
            else if(d==2)
                result += "화";
            else if(d==3)
                result +="수";
            else if(d==4)
                result += "목";
            else if(d==5)
                result +="금";
            else if(d==6)
                result += "토";
            else
                result += "금";
        }
        result += Integer.toString(e);
        if(f == 0){
            result += "시\n";
        }
        if(f != 0){
            result += "시";
            result += Integer.toString(f);
            result += "분\n";
        }
        return result;
    }

    public int join(String login_id, String course_id, Integer class_id, Integer credits){
        String SQL="INSERT INTO takes VALUES (?, ?, ?, ?)";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setInt(1, Integer.parseInt(login_id));
            pstat.setString(2, course_id);
            pstat.setInt(3, class_id);
            pstat.setInt(4, credits);

            return pstat.executeUpdate();
        } catch (Exception e){
            e.printStackTrace();
        }
        return -1;
    }
    public int hope(String login_id, String course_id, Integer class_id, Integer credits){
        String SQL="INSERT INTO hope VALUES (?, ?, ?, ?)";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setInt(1, Integer.parseInt(login_id));
            pstat.setString(2, course_id);
            pstat.setInt(3, class_id);
            pstat.setInt(4, credits);

            return pstat.executeUpdate();
        } catch (Exception e){
            e.printStackTrace();
        }
        return -1;
    }
    public int check(String login_id, String course_id){
        String SQL = "SELECT grade_num FROM credit WHERE ID=? and course_id = ?";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setInt(1, Integer.parseInt(login_id));
            pstat.setString(2, course_id);
            rs = pstat.executeQuery();
            if(rs.next()){
                if(rs.getInt("grade_num")<3){
                    return 1; // 재수강 가능
                }
                else
                    return 0; // 재수강 불가능
            }
            return -1; //처음 수강함
        }catch (Exception e){
            e.printStackTrace();
        }
        return -2; // 데이터베이스 오류
    }
    public int delete(String login_id, String course_id, Integer class_id, Integer credits){
        String SQL="DELETE FROM takes WHERE ID=? and course_id = ? and class_id = ? and credits= ?";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setInt(1, Integer.parseInt(login_id));
            pstat.setString(2, course_id);
            pstat.setInt(3, class_id);
            pstat.setInt(4, credits);

            return pstat.executeUpdate();
        } catch (Exception e){
            e.printStackTrace();
        }
        return -1;
    }
    public int hope_delete(String login_id, String course_id, Integer class_id, Integer credits){
        String SQL="DELETE FROM hope WHERE ID=? and course_id = ? and class_id = ? and credits= ?";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setInt(1, Integer.parseInt(login_id));
            pstat.setString(2, course_id);
            pstat.setInt(3, class_id);
            pstat.setInt(4, credits);

            return pstat.executeUpdate();
        } catch (Exception e){
            e.printStackTrace();
        }
        return -1;
    }
}
