package USER;

public class User {
    private String login_id;
    private String login_pwd;
    private String table_name;
    private String total_credit;
    private String student_name;
    private Integer ID;
    public Integer getID() {
        return ID;
    }
    public void setID(Integer ID) {
        this.ID = ID;
    }
    public String getLogin_id(){
        return login_id;
    }
    public void setLogin_id(String login_id){
        this.login_id = login_id;
    }
    public String getLogin_pwd(){
        return login_pwd;
    }
    public void setLogin_pwd(String login_pwd){
        this.login_pwd = login_pwd;
    }
    public String getTable_name(){
        return table_name;
    }
    public void setTable_name(String table_name){
        this.table_name = table_name;
    }
    public String getTotal_credit(){
        return total_credit;
    }
    public void setTotal_credit(String total_credit){
        this.total_credit = total_credit;
    }
    public String getStudent_name() {
        return student_name;
    }
    public void setStudent_name(String student_name) {
        this.student_name = student_name;
    }
}
