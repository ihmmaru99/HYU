package USER;
import java.sql.*;

public class UserDAO {
    private Connection conn;
    private PreparedStatement pstat;
    private ResultSet rs;
    public UserDAO(){
        try{
            String dbURL = "jdbc:mysql://localhost:3307/DB2018004584?serverTimezone=Asia/Seoul";
            String dbID = "root";
            String dbPW = "";

            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(dbURL, dbID, dbPW);
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public int std_login(String login_id, String login_pwd){
        String SQL = "SELECT login_pwd FROM student WHERE login_id = ?";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setString(1, login_id);
            rs=pstat.executeQuery();

            if(rs.next()){
                if(rs.getString(1).equals(login_pwd)){
                    return 1; // 로그인 성공
                }
                else
                    return 0; // 비밀번호 틀림
            }
            return -1; //ID 없음
        } catch (Exception e){
            e.printStackTrace();
        }
        return -2; //데이터베이스 오류
    }
    public int lec_login(String login_id, String login_pwd){
        String SQL = "SELECT login_pwd FROM lecturer WHERE login_id = ?";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setString(1, login_id);
            rs=pstat.executeQuery();

            if(rs.next()){
                if(rs.getString(1).equals(login_pwd)){
                    return 1; // 로그인 성공
                }
                else
                    return 0; // 비밀번호 틀림
            }
            return -1; //ID 없음
        } catch (Exception e){
            e.printStackTrace();
        }
        return -2; //데이터베이스 오류
    }
    public int total_credit(String login_id){
        String SQL = "SELECT SUM(credits) as total_credit FROM student natural join takes  WHERE ID=?";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setString(1, login_id);
            rs=pstat.executeQuery();

            if(rs.next()) {
                return rs.getInt("total_credit");
            }
        } catch (Exception e){
            e.printStackTrace();
        }
        return 0; //데이터베이스 오류
    }
    public String student_name(String login_id){
        String SQL = "SELECT student_name FROM student WHERE ID=?";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setString(1, login_id);
            rs=pstat.executeQuery();

            if(rs.next()) {
                return rs.getString("student_name");
            }
        } catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
    public String lecturer_name(String login_id){
        String SQL = "SELECT lecturer_name FROM lecturer WHERE ID=?";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setString(1, login_id);
            rs=pstat.executeQuery();

            if(rs.next()) {
                return rs.getString("lecturer_name");
            }
        } catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
}

