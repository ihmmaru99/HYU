package MANAGE;

public class Manage {
    private Integer person_max;
    private Integer class_id;
    private String course_id;
    private Integer credits;
    private Integer student_year;
    private Integer room_id;
    private Integer building_id;
    private Integer lecturer_id;
    private String lecturer_name;
    private String dept_name;
    private String title;
    private String start_time;
    private String end_time;
    private String date;
    private Double grade_num;

    public Double getGrade_num() {
        return grade_num;
    }

    public void setGrade_num(Double grade_num) {
        this.grade_num = grade_num;
    }

    public String getStart_time() {
        return start_time;
    }

    public String getEnd_time() {
        return end_time;
    }

    public String getDate() {
        return date;
    }

    public void setStart_time(String start_time) {
        this.start_time = start_time;
    }

    public void setEnd_time(String end_time) {
        this.end_time = end_time;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public Integer getPerson_max() {
        return person_max;
    }
    public Integer getClass_id() {
        return class_id;
    }
    public String getCourse_id() {
        return course_id;
    }
    public Integer getCredits() {
        return credits;
    }
    public Integer getStudent_year() {
        return student_year;
    }
    public Integer getRoom_id() {
        return room_id;
    }
    public Integer getBuilding_id() {
        return building_id;
    }
    public Integer getLecturer_id() {
        return lecturer_id;
    }
    public String getLecturer_name() {
        return lecturer_name;
    }
    public String getDept_name() {
        return dept_name;
    }
    public void setPerson_max(Integer person_max) {
        this.person_max = person_max;
    }
    public void setClass_id(Integer class_id) {
        this.class_id = class_id;
    }
    public void setCourse_id(String course_id) {
        this.course_id = course_id;
    }
    public void setCredits(Integer credits) {
        this.credits = credits;
    }
    public void setStudent_year(Integer student_year) {
        this.student_year = student_year;
    }
    public void setRoom_id(Integer room_id) {
        this.room_id = room_id;
    }
    public void setBuilding_id(Integer building_id) {
        this.building_id = building_id;
    }

    public void setLecturer_id(Integer lecturer_id) {
        this.lecturer_id = lecturer_id;
    }

    public void setLecturer_name(String lecturer_name) {
        this.lecturer_name = lecturer_name;
    }

    public void setDept_name(String dept_name) {
        this.dept_name = dept_name;
    }
}
