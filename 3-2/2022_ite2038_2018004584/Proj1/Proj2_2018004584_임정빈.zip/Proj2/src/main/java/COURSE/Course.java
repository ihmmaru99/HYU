package COURSE;

public class Course {
    private Integer class_id;
    private String course_id;
    private String title;
    private Integer credits;
    private Integer person_max;
    private Integer course_person;
    public Integer getCourse_person() {
        return course_person;
    }

    public void setCourse_person(Integer course_person) {
        this.course_person = course_person;
    }

    public Integer getPerson_max() {
        return person_max;
    }

    public void setPerson_max(Integer person_max) {
        this.person_max = person_max;
    }

    public Integer getCredits() {
        return credits;
    }

    public void setCredits(Integer credits) {
        this.credits = credits;
    }

    public String getCourse_id() {
        return course_id;
    }

    public String getTitle() {
        return title;
    }

    public Integer getClass_id() {
        return class_id;
    }

    public void setClass_id(Integer class_id) {
        this.class_id = class_id;
    }

    public void setCourse_id(String course_id) {
        this.course_id = course_id;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
