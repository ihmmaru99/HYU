package MANAGE;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ManagerDAO {
    private Connection conn;
    private PreparedStatement pstat;
    private ResultSet rs;
    public ManagerDAO(){
        try{
            String dbURL = "jdbc:mysql://localhost:3307/DB2018004584?serverTimezone=Asia/Seoul";
            String dbID = "root";
            String dbPW = "";

            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection(dbURL, dbID, dbPW);
        } catch (Exception e){
            e.printStackTrace();
        }
    }
    public Integer updateCourse(Integer person_max, Integer class_id){
        String SQL = "UPDATE class SET person_max=? WHERE class_id=?";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setInt(1, person_max);
            pstat.setInt(2, class_id);
            return pstat.executeUpdate();
        } catch (Exception e){
            e.printStackTrace();
        }
        return -1; //데이터베이스 오류
    }
    public Integer make_time_id(String date, String time_id){
        String result = "";
        if(Integer.parseInt(date) == 0){
            return 0;
        }
        result += date;
        result += time_id;
        return Integer.parseInt(result);
    }
    public Integer check_person_max(Integer room_id){
        String SQL="SELECT occupancy FROM classroom WHERE room_id=?";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setInt(1, room_id);
            rs=pstat.executeQuery();

            if(rs.next()) {
                return rs.getInt("occupancy"); // 강의실 수강정원을 return함
            }
        } catch (Exception e){
            e.printStackTrace();
        }
        return 0;
    }
    public Integer check_time(Integer room_id, Integer start_time_id, Integer end_time_id){
        String SQL = "SELECT COUNT(*) AS cnt FROM class natural join class_time natural join classroom WHERE room_id=? and ((start_time_id>? and start_time_id <?) OR (end_time_id>? and end_time_id <?))";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setInt(1, room_id);
            pstat.setInt(2, start_time_id);
            pstat.setInt(3, end_time_id);
            pstat.setInt(4, start_time_id);
            pstat.setInt(5, end_time_id);
            rs=pstat.executeQuery();

            if(rs.next()) {
                return rs.getInt("cnt"); // 1이상의 숫자라면 해당 시간에 해당 강의실을 사용하는 것임
            }
        } catch (Exception e){
            e.printStackTrace();
        }
        return 0;
    }
    public Integer check_class_id(Integer class_id){
        String SQL = "SELECT COUNT(*) as cnt FROM class WHERE class_id=?";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setInt(1, class_id);
            rs = pstat.executeQuery();
            if(rs.next()){
                return rs.getInt("cnt");
            }
        } catch (Exception e){
            e.printStackTrace();
        }
        return 0;
    }
    public Integer check_course_id(String course_id){
        String SQL = "SELECT COUNT(*) as cnt FROM course WHERE course_id=?";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setString(1, course_id);
            rs = pstat.executeQuery();
            if(rs.next()){
                return rs.getInt("cnt");
            }
        } catch (Exception e){
            e.printStackTrace();
        }
        return 0;
    }
    public Integer make_class(Integer class_id, Integer login_id, String course_id, Integer student_year, Integer person_max, Integer room_id){
        String SQL = "INSERT INTO class VALUES(?, 2022, ?, ?, ?, ?, ?)";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setInt(1, class_id);
            pstat.setInt(2, login_id);
            pstat.setString(3, course_id);
            pstat.setInt(4, student_year);
            pstat.setInt(5, person_max);
            pstat.setInt(6, room_id);
            return pstat.executeUpdate();
        }catch (Exception e){
            e.printStackTrace();
        }
        return -1;
    }
    public Integer make_course(String course_id, String title, Integer credits){
        String SQL = "INSERT INTO course VALUES(?, ?, ?)";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setString(1, course_id);
            pstat.setString(2, title);
            pstat.setInt(3, credits);
            return pstat.executeUpdate();
        }catch (Exception e){
            e.printStackTrace();
        }
        return -1;
    }
    public Integer make_class_time(Integer class_id, Integer start_time_id, Integer end_time_id){
        String SQL = "INSERT INTO class_time VALUES(?, ?, ?)";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setInt(1, class_id);
            pstat.setInt(2, start_time_id);
            pstat.setInt(3, end_time_id);
            return pstat.executeUpdate();
        }catch (Exception e){
            e.printStackTrace();
        }
        return -1;
    }
    public Integer cancel_class(Integer class_id){
        String SQL = "DELETE FROM class WHERE class_id = ?";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setInt(1, class_id);
            return pstat.executeUpdate();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return -1;
    }
    public Integer cancel_takes(Integer class_id){
        String SQL = "DELETE FROM takes WHERE class_id = ?";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setInt(1, class_id);
            return pstat.executeUpdate();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return -1;
    }
    public Integer cancel_hope(Integer class_id){
        String SQL = "DELETE FROM hope WHERE class_id = ?";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setInt(1, class_id);
            return pstat.executeUpdate();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return -1;
    }
    public String grade(Double grade_num){
        String result = "";
        if(grade_num == 4.5)
            result += "A+";
        else if(grade_num == 4.0)
            result += "A0";
        else if(grade_num == 3.5)
            result += "B+";
        else if(grade_num == 3.0)
            result += "B0";
        else if(grade_num == 2.5)
            result += "C+";
        else if(grade_num == 2.0)
            result += "C0";
        else if(grade_num == 1.5)
            result += "D+";
        else if(grade_num == 1.0)
            result += "D0";
        else
            result += "F";
        return result;
    }
    public int delete_takes(Integer ID, String course_id){
        String SQL = "DELETE FROM takes WHERE ID=? AND course_id=?";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setInt(1, ID);
            pstat.setString(2, course_id);
            return pstat.executeUpdate();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return -1;
    }
    public int insert_credit(Integer ID, String course_id, String grade, Double grade_num){
        String SQL = "INSERT INTO credit values(?,?,?,?)";
        try{
            pstat = conn.prepareStatement(SQL);
            pstat.setInt(1, ID);
            pstat.setString(2, course_id);
            pstat.setString(3, grade);
            pstat.setDouble(4, grade_num);
            return pstat.executeUpdate();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return -1;
    }
}
